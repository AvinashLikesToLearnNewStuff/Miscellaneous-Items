const express = require("express");
const path = require("path");
const app = express();
const port = 80;

//Express specific configuration
app.use("/static", express.static("static")); //for serving static files

app.set("view engine", "pug"); //for setting pug as the templating engine

app.set("views", path.join(__dirname, "views")); //set the views directory

app.get("/", (req, res) => {
  const con =
    "the suffering that you are going through right now, is not more than the pleasure you will get later";
  const params = {
    title: "pug is great but I love huskies more",
    content: con,
  };
  res.status(200).render("index.pug", params);
});

app.post("/", (req, res) => {
  const params = {
    message: "your form has been submitted sucessfully",
    content: con,
  };
  res.status(200).render("index.pug", params);
});

app.listen(port, () => {
  console.log(`the application started successfully on port ${port}`);
});
